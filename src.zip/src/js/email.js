// // Your web app's Firebase configuration
// var firebaseConfig = {
//     apiKey: "AIzaSyAtLIIelGxM899dnJMKdFZqkSMdy-6iqZg",
//     authDomain: "gency-2e0cc.firebaseapp.com",
//     projectId: "gency-2e0cc",
//     storageBucket: "gency-2e0cc.appspot.com",
//     messagingSenderId: "773278501415",
//     appId: "1:773278501415:web:1ad5c668596c9f0f045c02",
//     measurementId: "G-5J8YW20W7J"
// };
// // Initialize Firebase
// firebase.initializeApp(firebaseConfig);
// firebase.analytics();

// // Refernece contactInfo collections
// let contactInfo = firebase.database().ref("infos");

// // Listen for a submit
// document.querySelector(".contact-form").addEventListener("submit", submitForm);

// function submitForm(e) {
//     e.preventDefault();

//     //   Get input Values
//     //let name = document.querySelector(".name").value;
//     let email = document.querySelector(".email").value;
//     //let message = document.querySelector(".message").value;
//     console.log(email);

//     saveContactInfo(email);

//     document.querySelector(".contact-form").reset();
// }

// // Save infos to Firebase
// function saveContactInfo(email) {
//     let newContactInfo = contactInfo.push();

//     newContactInfo.set({
//         email: email,
//     });
// }